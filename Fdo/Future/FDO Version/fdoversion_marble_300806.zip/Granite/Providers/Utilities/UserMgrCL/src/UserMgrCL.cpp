/*
 * Copyright (C) 2004-2006  Autodesk, Inc.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of version 2.1 of the GNU Lesser
 * General Public License as published by the Free Software Foundation.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Revision Control Modification History
 *
 *         $Id: $
 *     $Author: $
 *   $DateTime: $
 *     $Change: $
 *
 */

#include "stdafx.h"

#include <stdlib.h>
#ifdef _WIN32
#include <conio.h>
#endif
#include <ctype.h>
#include <malloc.h>

#ifndef _WIN32
#include <inc/ut.h>
#include <unistd.h>
#include <termios.h>
#endif

#include "UserMgrIO.h"


#ifdef _WIN32
char *usermgrcl_cat = "FdoUserManagerMsg.dll";
#else
char *usermgrcl_cat = "FdoUserManagerMsg.cat";
#endif


class CUserMgrCLApp
{

public:
    CUserMgrCLApp ()
    {
    }

    ~CUserMgrCLApp ()
    {
    }

    enum ProviderType
    {
        ProviderType_Oracle,
        ProviderType_SqlServer,
        ProviderType_MySql,
        //ProviderType_Odbc,
        ProviderType_Unknown
    };

    ProviderType GetProviderType(FdoString* providerName)
    {
        wchar_t lowerProviderName[1024];
        wcscpy(lowerProviderName, providerName);
        wcslwr(lowerProviderName);

        if (NULL != wcsstr(lowerProviderName, L"oracle"))
            return ProviderType_Oracle;
        else if (NULL != wcsstr(lowerProviderName, L"sqlserver"))
            return ProviderType_SqlServer;
        else if (NULL != wcsstr(lowerProviderName, L"mysql"))
            return ProviderType_MySql;
//        else if (NULL != wcsstr(lowerProviderName, L"odbc"))
//            return ProviderType_Odbc;
        else
            return ProviderType_Unknown;
    }


    bool isEmpty (FdoString *prompt, FdoString* value)
    {
        bool ret;

        if ((NULL == value) || value[0] == 0)
        {
            report (WARN, prompt);
            ret = true;
        }
        else
            ret = false;

        return (ret);
    }


    // Asks the user to pick from a list of providers; returns fully-qualified provider name,
    // or empty string ("") if no providers selected
    FdoStringP askProviderName(int &choice)
    {
        FdoStringP providerName;

        FdoPtr<IProviderRegistry>  providerRegistry = FdoFeatureAccessManager::GetProviderRegistry();
        FdoPtr<FdoProviderCollection> providerList = providerRegistry->GetProviders();

        report (INFO, L"");
        report (INFO, NLSMSGGET(USERMGRCL_PROVIDERMENU_HEADER, "Choose a provider:"));
        report (INFO, NLSMSGGET(USERMGRCL_PROVIDERMENU_OPTION_0, "  0) Exit."));
        int iOptionNumber = 0;
        for (int i=0; i<providerList->GetCount(); i++)
        {
            FdoPtr<FdoProvider> provider = providerList->GetItem(i);
            if (GetProviderType(provider->GetName()) != ProviderType_Unknown)
                report (INFO, NLSMSGGET(USERMGRCL_PROVIDERMENU_OPTION, "  %1$d) %2$ls (version %3$ls)", ++iOptionNumber, provider->GetDisplayName(), provider->GetVersion()));
        }
        if (iOptionNumber == 0)
            report (INFO, NLSMSGGET(USERMGRCL_PROVIDERMENU_NONE_FOUND, "  [No RDBMS providers were found in the providers.xml registry]"));

        askInteger(&choice, NLSMSGGET(USERMGRCL_PROVIDERMENU_PROMPT, "Provider [%1$d]: ", choice));

        iOptionNumber = 1;
        providerName = L"";
        for (int i=0; i<providerList->GetCount(); i++)
        {
            FdoPtr<FdoProvider> provider = providerList->GetItem(i);
            if (GetProviderType(provider->GetName()) != ProviderType_Unknown)
            {
                if (iOptionNumber == choice)
                {
                    providerName = provider->GetName();
                    break;
                }
                else
                    iOptionNumber++;
            }
        }

        return providerName;
    }


    FdoStringP askConnectionString()
    {
        FdoStringP connString;
        FdoStringP answer;
        FdoStringP maskedPassword;

        // Get connection properties:
        // TODO: if user wants to input empty username/password after having entered non-empty ones (e.g. on SQL Server), it is impossible right now without restarting.
        askString (m_Service, NLSMSGGET(USERMGRCL_CONNPROPMENU_SERVICE_PROMPT, "Service [%1$ls]: ", (FdoString*)m_Service ));
        askString (m_UserName, NLSMSGGET(USERMGRCL_CONNPROPMENU_USERNAME_PROMPT, "Administrator Name [%1$ls]: ", (FdoString*)m_UserName ));
        askPassword (m_UserPassword, NLSMSGGET(USERMGRCL_CONNPROPMENU_USERPASSWORD_PROMPT, "Administrator Password [%1$ls]: ", hidePassword ((FdoString*)m_UserPassword, maskedPassword) ));

        // Build a connection string:
        FdoStringsP connectionProperties = FdoStringCollection::Create();
        if (m_Service.GetLength() > 0)
            connectionProperties->Add(FdoStringP::Format(L"Service=%ls", (FdoString*)m_Service));
        if (m_UserName.GetLength() > 0)
            connectionProperties->Add(FdoStringP::Format(L"Username=%ls", (FdoString*)m_UserName));
        if (m_UserPassword.GetLength() > 0)
            connectionProperties->Add(FdoStringP::Format(L"Password=%ls", (FdoString*)m_UserPassword));

        connString = connectionProperties->ToString(L"; ");
        return connString;
    }


    FdoStringsP askRolesPrivs(bool bRevoking = false)
    {
        while (true)
        {
            if (bRevoking)
                askString(m_InputRolesOrPrivileges, NLSMSGGET(USERMGRCL_ASSIGNROLEPRIV_ROLEPRIV_PROMPT_ALL, "Role or privilege names (separated by commas; type '?' for available list; type '*' for all; type '.' for none) [%1$ls]: ", (FdoString*)m_InputRolesOrPrivileges));
            else
                askString(m_InputRolesOrPrivileges, NLSMSGGET(USERMGRCL_ASSIGNROLEPRIV_ROLEPRIV_PROMPT, "Role or privilege names (separated by commas; type '?' for available list; type '.' for none) [%1$ls]: ", (FdoString*)m_InputRolesOrPrivileges));

            if (m_InputRolesOrPrivileges == L"?")
                listRolesPrivs(bRevoking);
            else if (m_InputRolesOrPrivileges == L".")
            {
                m_InputRolesOrPrivileges = L"";
                break;
            }
            else
                break;
        }

        FdoStringsP rolesOrPrivsCollection = FdoStringCollection::Create(m_InputRolesOrPrivileges, L",");
        return rolesOrPrivsCollection;
    }


    bool askContinue(void)
    {
        FdoStringP answer;

        askString(answer, NLSMSGGET(USERMGRCL_PROMPT_CONTINUE, "Continue? (Y/N) [Y]: "));
        return (answer != L"n" && answer != L"N");
    }


    FdoStringP CombineDomainAndUser(FdoString* userDomainName, FdoString* userName)
    {
        FdoStringP combined;

        if (userDomainName != NULL && wcslen(userDomainName) > 0)
            combined = FdoStringP::Format(L"%ls\\%ls", userDomainName, userName);
        else if (userName != NULL && wcslen(userName) > 0)
            combined = userName;
        
        return combined;
    }


    void listDatastores ()
    {
        report (INFO, L"");
        report (INFO, NLSMSGGET(USERMGRCL_LISTDATASTORES_HEADER, "The following is the list of all datastores:"));

	    FdoStringsP datastores = m_UserMgr->GetDatastores();
        int iDatastoreCount = 0;
        for (int i=0; i<datastores->GetCount(); i++)
        {
            FdoStringP datastore = FdoStringElementP(datastores->GetItem(i))->GetString();

            report (INFO, NLSMSGGET(USERMGRCL_LISTITEM, "  %1$ls", (FdoString*)datastore));

            if ((++iDatastoreCount % PAGESIZE) == 0)
                if (!askContinue())
                    break;
        }
    }


    void addUser ()
    {
        FdoStringP userPassword;
        FdoStringP userPasswordConfirmed;
        FdoStringP maskedPassword;

        // Get user name:
        do
        {
            askString (m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName));
        }
        while (isEmpty (NLSMSGGET(USERMGRCL_BLANK_USERNAME, "User name cannot be blank."), (FdoString*)m_InputUserName));

        // Get user password (ask twice to detect typos):
        do
        {
            do
            {
                askPassword (userPassword, NLSMSGGET(USERMGRCL_PROMPT_PASSWORD, "User Password [%1$ls]: ", hidePassword ((FdoString*)userPassword, maskedPassword)));
            }
            while (isEmpty (NLSMSGGET(USERMGRCL_BLANK_PASSWORD, "User password cannot be blank."), (FdoString*)userPassword));

            if (!askPassword (userPasswordConfirmed, NLSMSGGET(USERMGRCL_PROMPT_PASSWORD_CONFIRM, "Confirm User Password: ")))
                userPasswordConfirmed = L"";
            if (wcscmp (userPassword, userPasswordConfirmed))
                report (WARN, NLSMSGGET(USERMGRCL_PASSWORD_DIDNT_MATCH, "Password did not match."));
        }
        while (wcscmp (userPassword, userPasswordConfirmed));

        // Add the new user:
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");
        for (int i=0; i<userNames->GetCount(); i++)
        {
            m_UserMgr->AddUser(FdoStringElementP(userNames->GetItem(i))->GetString(), userPassword);
        }

        // Now prompt for roles/privilegs to add to this new users:
        assignRolesPrivsToUser(m_InputUserName);
    }


    void dropUser ()
    {
        // Get user name:
        do
        {
            askString (m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName));
        }
        while (isEmpty (NLSMSGGET(USERMGRCL_BLANK_USERNAME, "User name cannot be blank."), (FdoString*)m_InputUserName));

        // Drop the user:
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");
        for (int i=0; i<userNames->GetCount(); i++)
            m_UserMgr->DropUser(FdoStringElementP(userNames->GetItem(i))->GetString());
    }


    void listUsers ()
    {
        report (INFO, L"");
        report (INFO, NLSMSGGET(USERMGRCL_LISTUSERS_HEADER, "The following is the list of all users:"));

    	FdoPtr<FdoDbUserReader> userReader = m_UserMgr->GetDbUsers();
        int iUserCount = 0;
        while (userReader->ReadNext())
        {
            FdoStringP userName = userReader->GetName();
            FdoString* userDomain = userReader->GetDomain();

            userName = CombineDomainAndUser(userDomain, userName);

            report (INFO, NLSMSGGET(USERMGRCL_LISTITEM, "  %1$ls", (FdoString*)userName));

            if ((++iUserCount % PAGESIZE) == 0)
                if (!askContinue())
                    break;
        }
    }


    void showHelp ()
    {
        report (INFO, L"");
        report (INFO, NLSMSGGET(USERMGRCL_HELP_MAIN,
"The following commands are supported by FdoUserManager;\n"
"Note that the visibility of users, roles, privileges and datastores may be\n"
"limited by the administrator's own privileges:\n"
"\n"
"  0) Exit: Exits this process.\n"
"  1) Help: Displays this help message.\n"
"  2) Describe this Provider: Displays whether or not the current provider\n"
"        supports datastore grants or Windows authentication.\n"
"  3) Add a New User: Creates one or more new users on the current service.\n"
"        On SQL Server, there is an option to use Windows Authentication and\n"
"        if it is selected, a domain name is requested.\n"
"  4) Add a Windows User:  Adds one or more existing Windows user to the\n"
"        current service.\n"
"        This option is currently valid for SQL Server only.\n"
"  5) Drop a User:  Deletes one or more users from the current service.\n"
"  6) Assign Roles or Privileges to a User [In a Datastore]:  On Oracle, grants\n"
"        one or more roles or privileges to one or more users.  On SQL Server\n"
"        and MySql, grants one or more roles or privileges to one or more users\n"
"        in one or more datastores.  On SQL Server, this will also add the user\n"
"        to the datastore's user list.  Entering '?' will display a list of\n"
"        available roles and privileges to grant.\n"
"  7) Revoke Roles or Privileges From a User [In a Datastore]:  On Oracle,\n"
"        revokes one or more roles or privileges from one or more users.  On\n"
"        SQL Server and MySql, revokes one or more roles or privileges from one\n"
"        or more users in one or more datastores.  Entering '?' will display a\n"
"        list of available roles and privileges to revoke.  Entering '*' will\n"
"        revoke all roles from this user, and on SQL Server will also remove\n"
"        the user from the datastore's user list.\n"
"  8) List all Roles and Privileges of a User [In a Datastore]:  Displays\n"
"        all roles and privileges granted to one or more users.\n"
"  9) Grant a User Access to a Datastore:  Grants one or more users access\n"
"        to one or more datastores.\n"
"        This option is currently valid for SQL Server and MySql only.\n"
"  10) Revoke a User's Access to a Datastore:  Revokes access to one more\n"
"        datastores from one or more users.\n"
"        This option is currently valid for SQL Server and MySql only.\n"
"  11) List All Users [that Have Access to a Datastore]:   On Oracle,\n"
"        displays all users on the current service.  On SQL Server and MySql,\n"
"        Displays all users that currently have access to one or more given\n"
"        datastores.\n"
"  12) List All Available Roles and Privileges:  Displays all roles and\n"
"        privileges available on the current service.\n"
"  13) List All Datastores:  Displays all datastores available on the current\n"
"        service.\n"
));
    }


    void describeProvider ()
    {
        report(INFO, L"");

        if (m_UserMgr->SupportsDatastoreGrants())
            report(INFO, NLSMSGGET(USERMGRCL_DESCPROVIDER_SUPPORTSDATASTOREGRANTS, "The provider '%1$ls' supports Datastore grants.", (FdoString*)m_ProviderName));
        else
            report(INFO, NLSMSGGET(USERMGRCL_DESCPROVIDER_DOESNTSUPPORTDATASTOREGRANTS, "The provider '%1$ls' does not support Datastore grants.", (FdoString*)m_ProviderName));

        if (m_UserMgr->SupportsWindowsAuthentication())
            report(INFO, NLSMSGGET(USERMGRCL_DESCPROVIDER_SUPPORTSWINDOWSAUTHENTICATION, "The provider '%1$ls' supports Windows Authentication.", (FdoString*)m_ProviderName));
        else
            report(INFO, NLSMSGGET(USERMGRCL_DESCPROVIDER_DOESNTSUPPORTWINDOWSAUTHENTICATION, "The provider '%1$ls' does not support Windows Authentication.", (FdoString*)m_ProviderName));
    }


    void assignRolesPrivsToUser (FdoString* inputUserName = L"")
    {
        // Get user name:
        if (inputUserName == NULL || wcslen(inputUserName) == 0)
        {
            while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
                ;
        }
        else
        {
            // need to copy in 2 steps, since we may be copying from self to self which causes corrupt strings:
            FdoStringP temp = inputUserName;
            m_InputUserName = temp;
        }
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");

        // Get role/privilege name:
        FdoStringsP rolesOrPrivsCollection = askRolesPrivs();

        // Get datastore(s), for providers that require it:
        if ( ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
            && (userNames->GetCount() > 0) && (rolesOrPrivsCollection->GetCount() > 0) )
        {
            // Get datastore(s):
            while (!askString(m_InputDatastore, NLSMSGGET(USERMGRCL_CONNPROPMENU_DATASTORE_PROMPT, "Datastore(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputDatastore)))
                ;
        }

        // Assign these roles/privileges to user:
        FdoStringsP datastores = FdoStringCollection::Create(m_InputDatastore, L",");
        for (int i=0; i<rolesOrPrivsCollection->GetCount(); i++)
        {
            for (int j=0; j<userNames->GetCount(); j++)
            {
                if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                {
                    for (int k=0; k<datastores->GetCount(); k++)
                    {
                        m_UserMgr->GrantAccessToDatastore(
                            FdoStringElementP(userNames->GetItem(j))->GetString(),
                            FdoStringElementP(datastores->GetItem(k))->GetString(),
                            FdoStringElementP(rolesOrPrivsCollection->GetItem(i))->GetString()
                            );
                    }
                }
                else
                {
                    m_UserMgr->AssignRoleOrPrivilege(FdoStringElementP(userNames->GetItem(j))->GetString(),
                                                     FdoStringElementP(rolesOrPrivsCollection->GetItem(i))->GetString());
                }
            }
        }
    }


    void revokeRolesPrivsFromUser ()
    {
        // Get user name:
        while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
            ;
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");

#ifdef SUPPORT_FDO_USER_ROLE
        // Discourage users from trying to revoke the FDO_USER role:
        if (m_InputRolesOrPrivileges == L"FDO_USER")
            m_InputRolesOrPrivileges = L"";
#endif

        // Get role/privilege name:
        FdoStringsP rolesOrPrivsCollection = askRolesPrivs(true);

        // Get datastore(s), for providers that require it:
        if ( ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
            && (userNames->GetCount() > 0) && (rolesOrPrivsCollection->GetCount() > 0) )
        {
            // Get datastore(s):
            while (!askString(m_InputDatastore, NLSMSGGET(USERMGRCL_CONNPROPMENU_DATASTORE_PROMPT, "Datastore(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputDatastore)))
                ;
        }

        // Revoke these roles/privileges from user:
        FdoStringsP datastores = FdoStringCollection::Create(m_InputDatastore, L",");
        for (int i=0; i<rolesOrPrivsCollection->GetCount(); i++)
        {
            for (int j=0; j<userNames->GetCount(); j++)
            {
                if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                {
                    for (int k=0; k<datastores->GetCount(); k++)
                    {
                        m_UserMgr->RevokeAccessToDatastore(
                            FdoStringElementP(userNames->GetItem(j))->GetString(),
                            FdoStringElementP(datastores->GetItem(k))->GetString(),
                            FdoStringElementP(rolesOrPrivsCollection->GetItem(i))->GetString()
                            );
                    }
                }
                else
                {
                    m_UserMgr->RevokeRoleOrPrivilege(FdoStringElementP(userNames->GetItem(j))->GetString(),
                                                     FdoStringElementP(rolesOrPrivsCollection->GetItem(i))->GetString());
                }
            }
        }
    }


    void listUserRolesPrivs ()
    {
    	FdoPtr<FdoDbUserReader> userReader;

        // Get user name:
        while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
            ;
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");

        if (userNames->GetCount() > 0)
        {
            // If this is MySQL or SQL Server, get the datastore as well:
            if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
            {
                // Get datastore:
                while (!askString(m_InputSingleDatastore, NLSMSGGET(USERMGRCL_PROMPT_SINGLE_DATASTORE, "Datastore [%1$ls]: ", (FdoString*)m_InputSingleDatastore)))
                    ;

                userReader = m_UserMgr->GetDbUsers(m_InputSingleDatastore);
            }
            else
                userReader = m_UserMgr->GetDbUsers();

            // List all roles for the selected user(s) in the selected datastore (if relevant):
            bool bUserFound = false;
            while (userReader->ReadNext())
            {
                FdoStringP userNameReader = userReader->GetName();
                FdoStringP userDomainReader = userReader->GetDomain();

                userNameReader = CombineDomainAndUser(userDomainReader, userNameReader);

                for (int i=0; i<userNames->GetCount(); i++)
                {
					FdoStringP	userName = FdoStringElementP(userNames->GetItem(i))->GetString();

					// If this is SQL Server or Oracle, the user name is case insensitive:
					if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_Oracle))
						bUserFound = ( FdoCommonStringUtil::StringCompareNoCase( userNameReader, userName ) == 0 );
					else
						bUserFound = ( FdoCommonStringUtil::StringCompare( userNameReader, userName ) == 0 );

                    if (bUserFound)
                    {
                        FdoStringsP rolesPrivs = userReader->GetRolesOrPrivileges();

                        report (INFO, L"");
                        report (INFO, NLSMSGGET(USERMGRCL_LISTUSERROLESPRIVS_HEADER, "The following is the list of all roles and privileges granted to user '%1$ls':", (FdoString*)userNameReader));

                        int iRolePrivCount = 0;
                        for (int j=0; j<rolesPrivs->GetCount(); j++)
                        {
                            FdoStringElementP elem = rolesPrivs->GetItem(j);
                            report (INFO, NLSMSGGET(USERMGRCL_LISTITEM, "  %1$ls", (FdoString*)elem->GetString()));

                            if ((++iRolePrivCount % PAGESIZE) == 0)
                                if (!askContinue())
                                    break;
                        }

                        break;
                    }
                }
            }
            userReader = NULL;

            if (!bUserFound)
                report(ERR, NLSMSGGET(USERMGRCL_USERNAME_NOT_FOUND, "User name '%1$ls' not found.", (FdoString*)m_InputUserName));
        }
    }


    void grantUserAccessToDatastore ()
    {
        // Get user name(s):
        while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
            ;
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");

        if (userNames->GetCount() > 0)
        {
            // Get datastore(s):
            while (!askString(m_InputDatastore, NLSMSGGET(USERMGRCL_CONNPROPMENU_DATASTORE_PROMPT, "Datastore(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputDatastore)))
                ;
            FdoStringsP datastores = FdoStringCollection::Create(m_InputDatastore, L",");

            // Grant the given user(s) access to the given datastore(s):
            for (int i=0; i<userNames->GetCount(); i++)
                for (int j=0; j<datastores->GetCount(); j++)
                    m_UserMgr->GrantAccessToDatastore(FdoStringElementP(userNames->GetItem(i))->GetString(), FdoStringElementP(datastores->GetItem(j))->GetString());
        }
    }


    void revokeUserAccessToDatastore ()
    {
        // Get user name(s):
        while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
            ;
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");

        if (userNames->GetCount() > 0)
        {
            // Get datastore(s):
            while (!askString(m_InputDatastore, NLSMSGGET(USERMGRCL_CONNPROPMENU_DATASTORE_PROMPT, "Datastore(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputDatastore)))
                ;
            FdoStringsP datastores = FdoStringCollection::Create(m_InputDatastore, L",");

            // Grant the given user access to the given datastore:
            for (int i=0; i<userNames->GetCount(); i++)
                for (int j=0; j<datastores->GetCount(); j++)
                    m_UserMgr->RevokeAccessToDatastore(FdoStringElementP(userNames->GetItem(i))->GetString(), FdoStringElementP(datastores->GetItem(j))->GetString(), L"*");
        }
    }


    void listDatastoreUsers ()
    {
        // Get datastore(s):
        while (!askString(m_InputDatastore, NLSMSGGET(USERMGRCL_PROMPT_DATASTORE_ALLOW_EMPTY, "Datastore(s) (separated by commas; type '.' for global user list) [%1$ls]: ", (FdoString*)m_InputDatastore)))
            ;

        if (m_InputDatastore == L".")
            m_InputDatastore = L"";

        FdoStringsP datastores = FdoStringCollection::Create(m_InputDatastore, L",");

        if (datastores->GetCount() == 0)  // this indicates to get global user list
            listUsers();
        else
        {
            for (int j=0; j<datastores->GetCount(); j++)
            {
                FdoStringP datastore = FdoStringElementP(datastores->GetItem(j))->GetString();

                report (INFO, L"");
                report (INFO, NLSMSGGET(USERMGRCL_LISTDATASTOREUSERS_HEADER, "The following is the list of all users for datastore '%1$ls':", (FdoString*)datastore));

                // List users of this datastore;
    	        FdoPtr<FdoDbUserReader> userReader = m_UserMgr->GetDbUsers(datastore);
                int iUserCount = 0;
                while (userReader->ReadNext())
                {
                    FdoStringP userName = userReader->GetName();
                    FdoString* userDomain = userReader->GetDomain();

                    userName = CombineDomainAndUser(userDomain, userName);

                    report (INFO, NLSMSGGET(USERMGRCL_LISTITEM, "  %1$ls", (FdoString*)userName));

                    if ((++iUserCount % PAGESIZE) == 0)
                        if (!askContinue())
                            break;
                }
            }
        }
    }


    void listRolesPrivs (bool bRevoking = false)
    {
        FdoStringsP rolesAndPrivs = m_UserMgr->GetRolesOrPrivileges();

#ifdef SUPPORT_FDO_USER_ROLE
        // Discourage users from trying to revoke the FDO_USER role:
        if (bRevoking)
        {
            if (m_InputRolesOrPrivileges == L"FDO_USER")
                m_InputRolesOrPrivileges = L"";

            FdoInt32 index = rolesAndPrivs->IndexOf(L"FDO_USER");
            if (index >= 0)
                rolesAndPrivs->RemoveAt(index);
        }
#endif

        report (INFO, L"");
        report (INFO, NLSMSGGET(USERMGRCL_LISTROLESPRIVS_HEADER, "The following is the list of all available roles and privileges:"));

        int iUserCount = 0;
        for (int i=0; i<rolesAndPrivs->GetCount(); i++)
        {
            FdoStringElementP stringElem = rolesAndPrivs->GetItem(i);
            report(INFO, NLSMSGGET(USERMGRCL_LISTITEM, "  %1$ls",  (FdoString*)stringElem->GetString() ));

            if ((++iUserCount % PAGESIZE) == 0)
                if (!askContinue())
                    break;
        }
    }


    void addWindowsUser ()
    {
        // Get domain name:
        while (!askString(m_InputUserDomainName, NLSMSGGET(USERMGRCL_PROMPT_USERDOMAINNAME, "User Domain Name [%1$ls]: ", (FdoString*)m_InputUserDomainName)))
            ;

        // Get user name(s):
        while (!askString(m_InputUserName, NLSMSGGET(USERMGRCL_PROMPT_USER_NAME, "User Name(s) (separated by commas) [%1$ls]: ", (FdoString*)m_InputUserName)))
            ;

        // Add windows user(s):
        FdoStringsP userNames = FdoStringCollection::Create(m_InputUserName, L",");
        for (int i=0; i<userNames->GetCount(); i++)
            m_UserMgr->ApplyWindowsUser(m_InputUserDomainName, FdoStringElementP(userNames->GetItem(i))->GetString());
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////
    // MAIN METHOD:
    ///////////////////////////////////////////////////////////////////////////////////////////////
    void UserMgrCL ()
    {
        FdoStringP answer;
        int choice = 0;

        // Say hello:
        report (INFO, NLSMSGGET(USERMGRCL_VERSION, "Welcome to FdoUserManager V3.0"));

        // MAIN LOOP:
        do
        {
            // Get provider name from user:
            m_ProviderName = askProviderName(choice);
            if (m_ProviderName == L"")
                continue;
            m_ProviderType = GetProviderType(m_ProviderName);

            // Attempt to create FDO connection object for selected provider:
            FdoPtr<IConnectionManager> connMgr = FdoFeatureAccessManager::GetConnectionManager();
            FdoPtr<FdoIConnection> fdoConnection;
            try
            {
                fdoConnection = connMgr->CreateConnection(m_ProviderName);
            }
            catch (FdoException *e)
            {
                report (WARN, NLSMSGGET(USERMGRCL_ERROR_MSG, "Error: %1$ls", (FdoString*)SerializeException(e)));
                e->Release();
                continue;
            }

            // Attempt FDO connection to selected provider:
            FdoStringP connString = askConnectionString();
            fdoConnection->SetConnectionString(connString);
            FdoConnectionState connState;
            try
            {
                connState = fdoConnection->Open();
            }
            catch (FdoException *e)
            {
                report (WARN, NLSMSGGET(USERMGRCL_CONNECTION_FAILED_MSG, "Connection failed, re-enter connection parameters... [%1$ls]", (FdoString*)SerializeException(e)));
                e->Release();
                continue;
            }

            // Create FdoUserManager object:
            m_UserMgr = FdoUserManager::Create(fdoConnection);

            // Main loop for operations while connected:
            choice = 0;
            do
            {
                try
                {
                    report (INFO, L"");
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_HEADER, "Choose an operation: "));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_0, "  0) Exit."));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_1, "  1) Help"));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_2, "  2) Describe this Provider."));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_3, "  3) Add a New User."));
                    if (m_ProviderType == ProviderType_SqlServer)
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_4, "  4) Add a Windows User."));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_5, "  5) Drop a User."));

                    if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                    {
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_6a, "  6) Assign Roles or Privileges to a User In a Datastore."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_7a, "  7) Revoke Roles or Privileges From a User In a Datastore."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_8a, "  8) List all Roles and Privileges of a User in a Datastore."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_9,  "  9) Grant a User Access to a Datastore."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_10, "  10) Revoke a User's Access to a Datastore."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_11a,"  11) List All Users that Have Access to a Datastore."));
                    }
                    else
                    {
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_6b, "  6) Assign Roles or Privileges to a User."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_7b, "  7) Revoke Roles or Privileges From a User."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_8b, "  8) List all Roles and Privileges of a User."));
                        report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_11b,"  11) List All Users."));
                    }
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_12,"  12) List All Available Roles and Privileges."));
                    report (INFO, NLSMSGGET(USERMGRCL_MAINMENU_OPTION_13,"  13) List All Datastores."));

                    askInteger (&choice, NLSMSGGET(USERMGRCL_MAINMENU_PROMPT, "Operation [%1$d]: ", choice));
                    bool bBadChoice = false;
                    switch (choice)
                    {
                        case 0:
                            break;
                        case 1:
                            showHelp ();
                            break;
                        case 2:
                            describeProvider ();
                            break;
                        case 3:
                            addUser ();
                            break;
                        case 4:
                            if (m_ProviderType == ProviderType_SqlServer)
                                addWindowsUser ();
                            else
                                bBadChoice = true;
                            break;
                        case 5:
                            dropUser ();
                            break;
                        case 6:
                            assignRolesPrivsToUser ();
                            break;
                        case 7:
                            revokeRolesPrivsFromUser ();
                            break;
                        case 8:
                            listUserRolesPrivs ();
                            break;
                        case 9:
                            if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                                grantUserAccessToDatastore ();
                            else
                                bBadChoice = true;
                            break;
                        case 10:
                            if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                                revokeUserAccessToDatastore ();
                            else
                                bBadChoice = true;
                            break;
                        case 11:
                            if ((m_ProviderType == ProviderType_SqlServer) || (m_ProviderType == ProviderType_MySql))
                                listDatastoreUsers ();
                            else
                                listUsers();
                            break;
                        case 12:
                            listRolesPrivs ();
                            break;
                        case 13:
                            listDatastores ();
                            break;
                            // else fall through to default case
                        default:
                            bBadChoice = true;
                            break;
                    }

                    if (bBadChoice)
                        report (WARN, NLSMSGGET(USERMGRCL_WRONG_CHOICE, "Unrecognized choice."));
                    else if (0 != choice)
                        report (INFO, NLSMSGGET(USERMGRCL_OPERATION_SUCCESSFUL, "Operation successful."));
                }
                catch (FdoException *e)
                {
                    report(ERR, NLSMSGGET(USERMGRCL_OPERATION_FAILED_MSG, "Operation failed [%1$ls].", (FdoString*)SerializeException(e)));
                    e->Release();
                }
            }
            while (0 != choice);

        } while (0 != choice);

        // Say goodbye:
        report(INFO, L"");
        report(INFO, NLSMSGGET(USERMGRCL_EXIT, "Goodbye."));
    }


private:
    FdoStringP m_ProviderName;
    ProviderType m_ProviderType;
    FdoStringP m_Service;
    FdoStringP m_UserName;
    FdoStringP m_UserPassword;
    FdoPtr<FdoUserManager> m_UserMgr;

    // Cached input strings, to save the user from retyping the same thing over and over:
    FdoStringP m_InputRolesOrPrivileges;
    FdoStringP m_InputUserName;
    FdoStringP m_InputDatastore;
    FdoStringP m_InputSingleDatastore;
    FdoStringP m_InputUserDomainName;
};



#ifdef _WIN32
int addPath (char* dir)
{
    const char ENV_VAR[] = "PATH";
    const char PATH_SEP_CHAR = ';';
    char *path;
    size_t size;
    char *new_path;
    int ret = 0;

    path = getenv (ENV_VAR);
    size = strlen (ENV_VAR) + strlen (dir) + 3;
    if (NULL != path)
        size += strlen (path);
    new_path = new char[size];
    strcpy (new_path, ENV_VAR);
    strcat (new_path, "=");
    strcat (new_path, dir);
    size = strlen (new_path);
    new_path[size] = PATH_SEP_CHAR;
    new_path[size + 1] = '\0';
    if (NULL != path)
        strcat (new_path, path);
    if (!_putenv (new_path)) // returns 0 if successful, or ? in the case of an error
        ret = 1;
    delete[] new_path;

    return (ret);
}
#endif



#ifdef _WIN32
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char* argv[])
#endif
{
    CUserMgrCLApp *app;

#ifdef _WIN32
    char dir[MAX_PATH];
    char* p;

    if (0 != GetModuleFileName (NULL, dir, MAX_PATH))
    {
        // E.G. "C:\\Program Files\\Common Files\\Autodesk Shared\\FDO\\FDO\\3.0\\FdoUserManager.exe"
        p = strrchr (dir, '\\');
        if (NULL != p)
        {
            *p = '\0'; // E.G. "C:\\Program Files\\Common Files\\Autodesk Shared\\FDO\\FDO\\3.0"
            addPath (dir);
        }
    }
#endif

    app = new CUserMgrCLApp ();
    app->UserMgrCL ();
    delete app;

	return 0;
}
