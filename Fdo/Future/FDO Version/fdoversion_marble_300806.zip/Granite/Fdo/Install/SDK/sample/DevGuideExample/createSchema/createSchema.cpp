// createSchema.cpp
// a program to create schemas using the FDO API
//
// 
// Copyright (C) 2004-2006  Autodesk, Inc.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of version 2.1 of the GNU Lesser
// General Public License as published by the Free Software Foundation.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
// 
//


#include "stdafx.h"
#include <iostream>
#include <string>
#include "../Logger.h"
#include "../fdoinfo.h"
#include "../conversions.h"
#include "../ProviderConfigInfo.h"
#include <exception>
#include "../ExerciseFdoUtilities.h"
#include "../ExerciseFdoConnection.h"
#include "../SDFFile.h"
#include <Common/Io/FileStream.h>

using namespace std;

void
usage() {
	printf("Usage: createSchema <provider>.data <logFileName> destroySchema=<T|F> describeSchema=<T|F> applySchema=<T|F> deleteData=<T|F> [<featureClassName> <filter>]");
	printf(" deleteData=T <featureClassName> <filter>");
	exit(1);
}

int
main(int argc, char *argv[]) {
	bool destroySchemaBool = false;
	bool describeSchemaBool = false;
	bool applySchemaBool = false;
	bool deleteDataBool = false;

	if (argc < 7) {
		usage();
	}

   char * configFilename = argv[1];
   char * logFilename = argv[2];
   int retval = 0;

   Logger * log;
   try {
	   log = new Logger(logFilename);
   } catch (char * str) {
	   cout << str << endl;
	   return 1;
   }

   	// remember argv[0] has program name in it
   log->write("argv[1]:", configFilename);
   log->write("argv[2]:", logFilename);

	char * name = NULL;
	char * value = NULL;

   char * destroySchemaStr = argv[3];
   log->write("argv[3]:", destroySchemaStr);
   name = strtok(destroySchemaStr, "=");
   log->write("name:", name);
   value = strtok((char*)NULL, "=");
   log->write("value:", value);
   if (strcmp(name, "destroySchema") == 0) {
	   if (strcmp(value, "T") == 0) {
			   destroySchemaBool = true;
	   }
   }

   char * describeSchemaStr = argv[4];
   log->write("argv[4]:", describeSchemaStr);
   name = strtok(describeSchemaStr, "=");
   log->write("name:", name);
   value = strtok((char*)NULL, "=");
   log->write("value:", value);
   if (strcmp(name, "describeSchema") == 0) {
	   if (strcmp(value, "T") == 0) {
			   describeSchemaBool = true;
	   }
   }

   char * applySchemaStr = argv[5];
   log->write("argv[5]:", applySchemaStr);
   name = strtok(applySchemaStr, "=");
   log->write("name:", name);
   value = strtok((char*)NULL, "=");
   log->write("value:", value);
   if (strcmp(name, "applySchema") == 0) {
	   if (strcmp(value, "T") == 0) {
			   applySchemaBool = true;
	   }
   }

   char * filter = NULL;
   char * featureClassName = NULL;
   char * deleteDataStr = argv[6];
   log->write("argv[6]:", deleteDataStr);
   name = strtok(deleteDataStr, "=");
   log->write("name:", name);
   value = strtok((char*)NULL, "=");
   log->write("value:", value);
   if (strcmp(name, "deleteData") == 0) {
	   if (strcmp(value, "T") == 0) {
			if (argc < 9) {
				usage();
			}
			deleteDataBool = true;
			featureClassName = argv[7];
			log->write("argv[7]:", featureClassName);
			filter = argv[8];
			log->write("argv[8]:", featureClassName);
	   }
   }

  char sprintfBuf[1024];

   // declarations used throughout the program
   FdoPtr<FdoFgfGeometryFactory> geometryFactory;
   geometryFactory = FdoFgfGeometryFactory::GetInstance();

   Conversions convert;
   ProviderConfigInfo * configInfo;

   try {
	configInfo = new ProviderConfigInfo(configFilename, log, &convert);
   }
   catch (char * errMsg) {
	   log->write("ERROR: constructing configuration file object:", errMsg);
	   return 1;
   }
   ExerciseFdoUtilities utilities(log, &convert);
   FdoInfo info(log, &convert, &utilities, geometryFactory);
   
   FdoString* providerName;
   FdoPtr<IProviderRegistry> registry;
   FdoPtr<FdoProviderCollection> providers;
   bool containsProvider = false;
   FdoInt32 providerIndex = -1;

   // verity that the provider named in the config info file is already registered
   // log the entire registry
   try {
	   registry = FdoFeatureAccessManager::GetProviderRegistry();
	   providers = registry->GetProviders();
	   providerName = configInfo->getName();
	   sprintf(sprintfBuf, "config file provider name: \"%s\"", convert.wchar_tStarToCharStar(providerName));
	   log->write(sprintfBuf);
	   containsProvider = providers->Contains(providerName);
		if (containsProvider) {
			log->write("Providers list contains provider:", convert.boolToCharStar(containsProvider));
	   } else {
		   log->write("Registry does not contain provider:", convert.wchar_tStarToCharStar(configInfo->getName()));
		   return 1;
	   }
   }
   catch (FdoException * ex) {
	   log->write("Registration checkpoint exception message:");
	   utilities.PrintException(ex);
		ex->Release();
   }

   // create a connection object
   // use the connection object's connection property dictionary to set the connection string
   ExerciseFdoConnection * connectUtilities;
   FdoPtr<FdoIConnection> connection;
   FdoPtr<FdoIConnectionInfo> connectionInfo;
   static IConnectionManager* connectionManager;
   FdoIConnectionPropertyDictionary * connectionPropertyDictionary;
   try {
	   connectionManager = FdoFeatureAccessManager::GetConnectionManager();
 	   connection = connectionManager->CreateConnection(providerName);
	   connectionInfo = connection->GetConnectionInfo();
	   info.LogConnectionInfo(connectionInfo);
	   connectUtilities = new ExerciseFdoConnection(log, &convert, configInfo, registry,
		   connectionManager, connection);
	   connectionPropertyDictionary = connectionInfo->GetConnectionProperties();
	   connectUtilities->SetConnectionString(connectionPropertyDictionary);
	   log->write("connection->GetConnectionString():", convert.wchar_tStarToCharStar(connection->GetConnectionString()));
   } catch(FdoException* ex) {
	   log->write("Setting connection string exception message:");
	   utilities.PrintException(ex);
		ex->Release();
	   return 1;
   }

	SDFFile * sdfFile = NULL;
   // if this is the SDF provider and the SDF file doesn't exist,
   // create it
   // if it doesn't exist, you will get an error when you try to open a connection to it
#ifdef _WIN32
   if (_wcsnicmp(L"Autodesk.Sdf.", connectionInfo->GetProviderName(), 13) == 0) {
#else
   if (wcsncasecmp(L"Autodesk.Sdf.", connectionInfo->GetProviderName(), 13) == 0) {
#endif
		log->write("Delete and recreate the SDF file");
		try {
			sdfFile = new SDFFile(connection, log);
			sdfFile->DeleteAndRecreateSDFFile(configInfo->getFile());
	   }
		catch(char * errMsg) {
			log->write("Create SDF File character exception message:", errMsg);
			return 1;
		}
		catch(FdoException * ex) {
			log->write("Create SDF File FDO exception message:");
			utilities.PrintException(ex);
			ex->Release();
			return 1;
		}
   }

   // if this is the SHP provider 
   // pass the SHP schema file to the connection while it is still not open
   bool isShpProvider = FALSE;
#ifdef _WIN32
   if (_wcsnicmp(L"Autodesk.Shp.", connectionInfo->GetProviderName(), 13) == 0) {
#else
   if (wcsncasecmp(L"Autodesk.Shp.", connectionInfo->GetProviderName(), 13) == 0) {
#endif
		log->write("pass the SHP schema file to the connection object before opening connection");
		isShpProvider = TRUE;
		try {
			FdoStringP * accessMode = new FdoStringP("r");
			FdoPtr<FdoIoFileStream> fileStream = FdoIoFileStream::Create(configInfo->getEditedXmlSchemaFileName(), accessMode->operator FdoString *());
			connection->SetConfiguration(fileStream);
	   }
		catch(FdoException * ex) {
			log->write("Configure SHP schema file FDO exception message:");
			utilities.PrintException(ex);
			ex->Release();
			return 1;
		}
   }

   FdoConnectionState connectionState;
   try {
	   connectionState = connection->Open();
	   switch (connectionState) {
		case FdoConnectionState_Busy : 
			log->write("connection->Open() returned Busy:");
			return 1;
		case FdoConnectionState_Closed : 
			log->write("connection->Open() returned Closed:");
			return 1;
		case FdoConnectionState_Open : 
			break;
		case FdoConnectionState_Pending : 
			connectionInfo = connection->GetConnectionInfo();
			info.LogConnectionInfo(connectionInfo);
			connectionPropertyDictionary = connectionInfo->GetConnectionProperties();
			connectUtilities->SetConnectionString(connectionPropertyDictionary);
		   log->write("Connection string after setting datastore property:", convert.wchar_tStarToCharStar(connection->GetConnectionString()));
		   // the effect of the first Open() is to set the list of named datastores in the datastore property in the property dictionary
		   // get the datastore value from the config info and make sure it's in the list of named datastores
		   connectionState = connection->Open();
		   log->write("Connection State after second call to Open():", info.GetConnectionStateName(connectionState));
		   if (connectionState != FdoConnectionState_Open) {
			   log->write("Connection failed");
			   return 1;
		   }
			break;
		default :
			log->write("connection->Open() returned unknown enum:", convert.FdoInt32ToCharStar((FdoInt32)connectionState));
			return 1;
	   }
	   log->write("Connection State:", info.GetConnectionStateName(connectionState));
   }
   catch (FdoException* ex) {
	   log->write("Open connection checkpoint exception message:");
	   utilities.PrintException(ex);
		ex->Release();
	   return 1;
   }

   // feature schema declarations
   FdoPtr<FdoFeatureSchema> featureSchema;
   FdoPtr<FdoFeatureSchemaCollection> featureSchemaCollection = FdoFeatureSchemaCollection::Create(NULL);


  // create the commands that will be used over and over
   FdoPtr<FdoIApplySchema> applySchema;
   FdoPtr<FdoIDestroySchema> destroySchema;
   FdoPtr<FdoIDescribeSchema> describeSchema;
   FdoPtr<FdoIDelete> deleteCmd;
   FdoInt32 numDeleted = 0;
	try {
		applySchema = (FdoIApplySchema *)connection->CreateCommand(FdoCommandType_ApplySchema);
		describeSchema = (FdoIDescribeSchema *)connection->CreateCommand(FdoCommandType_DescribeSchema);
		if (!isShpProvider) {
			destroySchema = (FdoIDestroySchema *)connection->CreateCommand(FdoCommandType_DestroySchema);
		}
		deleteCmd = (FdoIDelete *)connection->CreateCommand(FdoCommandType_Delete);
   }
   catch (FdoException* ex) {
	   log->write("Create commands checkpoint exception message:");
	   utilities.PrintException(ex);
	   ex->Release();
   }


 	if (deleteDataBool) {
		log->write("If necessary, delete any data in datastore first.");
		try {
			deleteCmd->SetFeatureClassName(convert.charStarToWchar_tStar(featureClassName));
			deleteCmd->SetFilter(convert.charStarToWchar_tStar(filter));
			log->write("About to execute delete cmd");
			numDeleted = deleteCmd->Execute();
			sprintf(sprintfBuf, "Number deleted: %s", convert.FdoInt32ToCharStar(numDeleted));
			log->write(sprintfBuf);
		}
		catch (FdoException * ex) {
			log->write("Delete checkpoint exception message:");
			utilities.PrintException(ex);
			ex->Release();
		}
	}

	if (destroySchemaBool) {
		log->write("Destroy a schema created by reading an edited xml schema file.");
		try {
			destroySchema->SetSchemaName(configInfo->getEditedXmlSchemaName());
			destroySchema->Execute();
		}
		catch (FdoException * ex) {
			log->write("DestroySchema checkpoint exception message:");
			utilities.PrintException(ex);
			ex->Release();
		}
	}

	if (applySchemaBool) {
		try {
//			if (!isShpProvider) {
				log->write("Create a schema by reading from an edited xml file.");
				const wchar_t* fileName = configInfo->getEditedXmlSchemaFileName();
				featureSchemaCollection->ReadXml(fileName);
				featureSchema = featureSchemaCollection->FindItem(configInfo->getEditedXmlSchemaName());
				applySchema->SetFeatureSchema(featureSchema);
//			}
			applySchema->Execute();
			featureSchemaCollection->Clear();
		}
		catch (FdoException * ex) {
			log->write("ApplySchema from edited xml checkpoint exception message:");
			utilities.PrintException(ex);
			ex->Release();
		}
	}

	if (describeSchemaBool) {
		log->write("Describe a schema.");
		int count = 0;
		try {
			featureSchemaCollection = describeSchema->Execute();
			count = featureSchemaCollection->GetCount();
			for(int i=0; i<count; i++) {
				featureSchema = featureSchemaCollection->GetItem(i);
				sprintf(sprintfBuf, "featureSchemaCollection[%d]: %ls", i, featureSchema->GetName());
				log->write(sprintfBuf);
			}
			featureSchema = featureSchemaCollection->FindItem(configInfo->getEditedXmlSchemaName());
			info.LogFeatureSchema(featureSchema);
			featureSchemaCollection->Clear();
		}
		catch (FdoException * ex) {
			log->write("DescribeSchema checkpoint exception message:");
			utilities.PrintException(ex);
			ex->Release();
		}
	}

   try {
	   connection->Close();
	   connectionState = connection->GetConnectionState();
	   log->write("Connection State:", info.GetConnectionStateName(connectionState));
   }
   catch (FdoException* ex) {
	   log->write("Connection close checkpoint exception message:");
	   utilities.PrintException(ex);
		ex->Release();
   }

   delete log;
   delete configInfo;
   delete connectUtilities;
   delete sdfFile;
   return 0; 
}

