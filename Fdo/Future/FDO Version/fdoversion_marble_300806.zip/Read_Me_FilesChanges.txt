*
******Fdocore******
Modified : Thirdparty/openssl\ms\w31dll.mak
Modified : Thirdparty/openssl\ms\ntdll.mak
Modified : Thirdparty/openssl\ms\nt.mak
Modified : Thirdparty/openssl\ms\cedll.mak
Modified : Thirdparty/openssl\ms\ce.mak
Modified : Thirdparty/openssl\crypto\buildinf.h
Modified : Fdo/Unmanaged\Src\Message\FDOMessage.mc
Modified : Fdo/Unmanaged\Src\Fdo\Xml\SchemaMapping.cpp
Modified : Fdo/Unmanaged\Src\Fdo\Xml\SpatialContextReader.cpp
Modified : Fdo/Unmanaged\Src\Fdo\Xml\FeatureReaderImpl.h
Modified : Fdo/Unmanaged\Src\Fdo\Schema\SchemaFromExternal.xslt
Modified : Fdo/Unmanaged\Src\Fdo\Schema\SchemaFromInternal.h
Modified : Fdo/Unmanaged\Src\Fdo\Schema\SchemaFromExternal.h
Modified : Fdo/Unmanaged\Src\Fdo\Schema\FeatureSchema.cpp
Modified : Fdo/Unmanaged\Src\Fdo\Schema\SchemaFromInternal.xslt
Modified : Fdo/Unmanaged\Src\Fdo\Commands\Schema\PhysicalSchemaMappingCollection.cpp
Modified : Fdo/Unmanaged\Src\Fdo\Commands\Schema\PhysicalSchemaMapping.cpp
Modified : Fdo/Unmanaged\Src\Fdo\ClientServices\ProviderNameTokens.cpp
Modified : Fdo/Unmanaged\Src\Fdo\ClientServices\ProviderRegistry.cpp
Modified : Fdo/Unmanaged\Src\Fdo\ClientServices\FeatureAccessManager.cpp
Modified : Fdo/Unmanaged\Src\Fdo\ClientServices\Provider.cpp
Modified : Fdo/Unmanaged\Src\Fdo\ClientServices\RegistryUtility.cpp
Modified : Fdo/Unmanaged\Src\Common\Xml\Xml.cpp
Modified : Fdo/Unmanaged\Src\Common\Xml\Writer.cpp
Modified : Fdo/Unmanaged\Inc\Fdo\Xml\SchemaMapping.h
Modified : Fdo/Unmanaged\Inc\Fdo\Xml\FeatureReader.h
Modified : Fdo/Unmanaged\Inc\Fdo\Schema\FeatureSchema.h
Modified : Fdo/Unmanaged\Inc\Fdo\Commands\Schema\PhysicalSchemaMapping.h
Modified : Fdo/Unmanaged\Inc\Fdo\ClientServices\Provider.h
Modified : Fdo/Unmanaged\Inc\Fdo\ClientServices\ProviderNameTokens.h
Modified : Fdo/Unmanaged\Inc\Fdo\ClientServices\ProviderRegistry.h
Modified : Fdo/Unmanaged\Inc\Fdo\ClientServices\FeatureAccessManager.h
Modified : Fdo/Unmanaged\Inc\Fdo\IProviderRegistry.h
Modified : Fdo/Unmanaged\Inc\Common\Xml\Xml.h
Modified : Fdo/Unmanaged\Fdo.vcproj
Modified : Fdo/UnitTest\IoTest.cpp
Modified : Fdo/UnitTest\schema_all1_master.txt
Modified : Fdo/UnitTest\ClientServicesTest.h
Modified : Fdo/UnitTest\schema_mappings_212_master.txt
Modified : Fdo/UnitTest\schema_ext_c_master.txt
Modified : Fdo/UnitTest\sc1b_master.txt
Modified : Fdo/UnitTest\sc2b_master.txt
Modified : Fdo/UnitTest\schema_merge2b_master.txt
Modified : Fdo/UnitTest\schema_refs1c_master.txt
Modified : Fdo/UnitTest\schema_ext_b_master.txt
Modified : Fdo/UnitTest\schema_all_v2_out_master.txt
Modified : Fdo/UnitTest\sc1a_master.txt
Modified : Fdo/UnitTest\SchemaTest.cpp
Modified : Fdo/UnitTest\sc2a_master.txt
Modified : Fdo/UnitTest\schema_refs1b_master.txt
Modified : Fdo/UnitTest\schema_merge2a_master.txt
Modified : Fdo/UnitTest\schema_ext_a_master.txt
Modified : Fdo/UnitTest\ExpressionTest.cpp
Modified : Fdo/UnitTest\schema_refs2_master.txt
Modified : Fdo/UnitTest\schema_refs1a_master.txt
Modified : Fdo/UnitTest\ClientServicesTest.cpp
Modified : Fdo/Docs\XmlSchema\FdoBase.xsd
Modified : Fdo/Docs\XmlSchema\FdoDocument.xsd
Modified : Fdo/Docs\XmlSchema\FdoOverride.xsd
Modified : Fdo/Managed\Src\OSGeo\Common\AssemblyVersion.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProvider.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgFeatureAccessManager.h
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProviderNameTokens.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProvider.h
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProviderRegistry.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProviderNameTokens.h
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgFeatureAccessManager.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\ClientServices\mgProviderRegistry.h
Modified : Fdo/Managed\Src\OSGeo\FDO\Schema\mgFeatureSchema.h
Modified : Fdo/Managed\Src\OSGeo\FDO\Schema\mgFeatureSchema.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\Xml\mgXmlSchemaMapping.h
Modified : Fdo/Managed\Src\OSGeo\FDO\Xml\mgXmlSchemaMapping.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\Commands\Schema\mgPhysicalSchemaMapping.h
Modified : Fdo/Managed\Src\OSGeo\FDO\Commands\Schema\mgPhysicalSchemaMapping.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\mgIProviderRegistry.h
Modified : Fdo/Managed\Src\OSGeo\FDO\AssemblyVersion.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\mgIProviderRegistryImp.cpp
Modified : Fdo/Managed\Src\OSGeo\FDO\mgIProviderRegistryImp.h
Modified : Fdo/Managed\Src\OSGeo\Geometry\AssemblyVersion.cpp
Modified : Fdo/Managed\Src\OSGeo\Spatial\AssemblyVersion.cpp
*
******ArcSDE******
*
******Rdbms******
*
******GDAL******
*
******SDF******
Modified : Providers/SDF/Src\UnitTest\SelectTest.cpp
*
******SHP******
*
******WFS******
*
******WMS******
Modified : Providers/WMS/Src\UnitTest\WmsTestSelect.h
Modified : Providers/WMS/Src\UnitTest\WmsTests.cpp
Modified : Providers/WMS/Src\UnitTest\WmsTestSelect.cpp
Modified : Providers/WMS/Managed\Src\OSGeo\FDO\Providers\WMS\Override\AssemblyVersion.cpp
