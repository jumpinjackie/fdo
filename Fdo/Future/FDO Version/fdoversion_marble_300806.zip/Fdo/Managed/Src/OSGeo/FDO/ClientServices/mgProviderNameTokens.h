/*
* Copyright (C) 2004-2006  Autodesk, Inc.
* 
* This library is free software; you can redistribute it and/or
* modify it under the terms of version 2.1 of the GNU Lesser
* General Public License as published by the Free Software Foundation.
* 
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
* 
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*/

#pragma  once

class FdoProviderNameTokens;

class FdoStringsP;
class FdoVectorP;

BEGIN_NAMESPACE_OSGEO_FDO_CLIENTSERVICES

/// \brief
/// A provider name tokenized into its company, name and version parts.
public __gc class ProviderNameTokens : public NAMESPACE_OSGEO_RUNTIME::Disposable
{
public private:
	inline FdoProviderNameTokens* GetImpObj();

protected:
	System::Void Dispose(System::Boolean disposing);

public:
	ProviderNameTokens(System::IntPtr unmanaged, System::Boolean autoDelete)
		: Disposable(unmanaged, autoDelete)
	{
	}

    /// \brief
    /// Tokenize a full provider name
    /// The name is usually of the form "[Company].[Provider].[Version]",
    /// e.g. "Autodesk.Oracle.3.2".
    /// 
    /// \param names 
    /// Input the provider name to tokenize
    /// 
    /// \return
    /// Returns FdoProviderNameTokens
    /// 
	ProviderNameTokens(System::String* name);

    /// \brief
    /// Gets all of the tokens in this provider name
    /// 
    /// \return
    /// Returns the collection of tokens. 
    ///   Element 0 is the company
    ///   Element 1 is the unqualified name
    ///   the rest of the elements are the individual parts of the version number.
    /// 
	System::String* GetNameTokens()[];

    /// \brief
    /// Gets all of the tokens in this provider name
    /// 
    /// \param includeVersion 
    /// Input a boolean flag indicating that the version information
    /// should be returned as a part of the provider name. When 
    /// includeVersion is true, the full provider name is returned. 
    /// When includeVersion is false, the version parts are omitted 
    /// from the returned name.
    /// 
    /// \return
    /// Returns the collection of tokens. 
    ///   Element 0 is the company
    ///   Element 1 is the unqualified name
    ///   the rest of the elements are the individual parts of the version number.
    /// 
	System::String* GetNameTokens( System::Boolean includeVersion )[];

    /// \brief
    /// Gets all of the version number components in this provider name
    /// 
    /// \return
    /// Returns the collection of version number components. For
    /// example, if the full provider name is "Autodesk.Oracle.3.1" then 
    /// {2,1} is returned.
    /// 
	System::Double GetVersionTokens()[];

    /// \brief
    /// Gets the local (unqualified) name of this provider.
    /// 
    /// \return
    /// Returns the local name ( without company and version ). For
    /// example, if the full provider name is "Autodesk.Oracle.3.1" then 
    /// "Oracle" is returned.
    /// 
	System::String* GetLocalName();

    /// \brief
    /// Converts the tokenized provider name back to a string.
    /// 
    /// \return
    /// Returns the tokenized provider name.
    /// 
    System::String* ToString();

    /// \brief
    /// Converts the tokenized provider name back to a string.
    /// 
    /// \param includeVersion 
    /// Input a boolean flag indicating that the version information
    /// should be returned as a part of the provider name. When 
    /// includeVersion is true, the full provider name is returned. 
    /// When includeVersion is false, the version parts are omitted 
    /// from the returned name.
    /// 
    /// \return
    /// Returns the tokenized provider name.
    /// 
    System::String* ToString( System::Boolean includeVersion );

private:
	static System::String *FdoStringsToStringArray(const FdoStringsP &sa)[];
	static System::Double FdoVectorToDoubleArrary(const FdoVectorP &da)[];
};

END_NAMESPACE_OSGEO_FDO_CLIENTSERVICES


