/*
* Copyright (C) 2004-2006  Autodesk, Inc.
* 
* This library is free software; you can redistribute it and/or
* modify it under the terms of version 2.1 of the GNU Lesser
* General Public License as published by the Free Software Foundation.
* 
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
* 
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*/

#pragma  once


BEGIN_NAMESPACE_OSGEO_FDO
public __gc __interface IConnectionManager;
public __gc __interface IProviderRegistry;
END_NAMESPACE_OSGEO_FDO

BEGIN_NAMESPACE_OSGEO_FDO_CLIENTSERVICES

/// \brief
/// The FeatureAccessManager class manages a registry of feature providers stored in the registry
/// and provides support for dynamic discovery and binding to registered feature providers
public __sealed __gc class FeatureAccessManager 
{
public:
    /// \brief
    /// Static method that gets an object that implements IConnection Manager
    /// 
    /// \return
    /// Returns a static instance of an IConnectionManager object. 
    /// 
	static NAMESPACE_OSGEO_FDO::IConnectionManager* GetConnectionManager();

    /// \brief
    /// Static method that gets an object that implements IProviderRegistry
    /// 
    /// \return
    /// Returns a static instance of an IProviderRegistry object. 
    /// 
	static NAMESPACE_OSGEO_FDO::IProviderRegistry* GetProviderRegistry();

    /// \brief
    /// Gets the version of the feature data objects specification the Feature Access Manager conforms to. 
    /// The version number string has the form [VersionMajor].[VersionMinor].[BuildMajor].[BuildMinor].
    /// 
    /// \return
    /// Returns the Feature Data Objects version as a constant wchar_t*.
    /// 
    static System::String* GetFeatureDataObjectsVersion();

private:
	FeatureAccessManager(){}
};

END_NAMESPACE_OSGEO_FDO_CLIENTSERVICES


