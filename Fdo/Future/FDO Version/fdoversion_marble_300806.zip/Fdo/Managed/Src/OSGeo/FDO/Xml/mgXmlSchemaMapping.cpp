/*
* 
* Copyright (C) 2004-2006  Autodesk, Inc.
* 
* This library is free software; you can redistribute it and/or
* modify it under the terms of version 2.1 of the GNU Lesser
* General Public License as published by the Free Software Foundation.
* 
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
* 
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*/

#include "stdafx.h"
#include <Fdo\Xml\SchemaMapping.h>
#include <Fdo\Commands\CommandType.h>

#include "FDO\Xml\mgXmlSchemaMapping.h"
#include "FDO\mgObjectFactory.h"
#include "FDO\Xml\mgXmlElementMappingCollection.h"
#include "FDO\Xml\mgXmlClassMappingCollection.h"

FdoXmlSchemaMapping* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::GetImpObj()
{
    return static_cast<FdoXmlSchemaMapping*>(__super::UnmanagedObject.ToPointer());
}

System::String* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::get_Provider()
{
	FdoString* result;

	EXCEPTION_HANDLER(result = GetImpObj()->GetProvider())

	return result;
}

System::Void NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::set_TargetNamespace(System::String* package)
{
	EXCEPTION_HANDLER(GetImpObj()->SetTargetNamespace(StringToUni(package)))
}

System::String* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::get_TargetNamespace()
{
	FdoString* result;

	EXCEPTION_HANDLER(result = GetImpObj()->GetTargetNamespace())

	return result;
}

NAMESPACE_OSGEO_FDO_XML::XmlElementMappingCollection* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::get_ElementMappings()
{
	FdoXmlElementMappingCollection* result;

	EXCEPTION_HANDLER(result = GetImpObj()->GetElementMappings())

    return NAMESPACE_OSGEO_FDO::ObjectFactory::CreateXmlElementMappingCollection(result, true);
}

NAMESPACE_OSGEO_FDO_XML::XmlClassMappingCollection* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::get_ClassMappings()
{
	FdoXmlClassMappingCollection* result;

	EXCEPTION_HANDLER(result = GetImpObj()->GetClassMappings())

	return NAMESPACE_OSGEO_FDO::ObjectFactory::CreateXmlClassMappingCollection(result, true);
}

System::String* NAMESPACE_OSGEO_FDO_XML::XmlSchemaMapping::get_MinimumProviderVersion()
{
	FdoStringP result;

	EXCEPTION_HANDLER(result = GetImpObj()->GetMinimumProviderVersion())

	return (FdoString*)result;
}

