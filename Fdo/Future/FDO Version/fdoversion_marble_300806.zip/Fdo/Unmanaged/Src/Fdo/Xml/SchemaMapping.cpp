// 
//  
//  Copyright (C) 2004-2006  Autodesk, Inc.
//  
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of version 2.1 of the GNU Lesser
//  General Public License as published by the Free Software Foundation.
//  
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//  
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//  
#include <FdoStd.h>
#include <Fdo/Xml/SchemaMapping.h>
#include <Fdo/ClientServices/FeatureAccessManager.h>
#include <Fdo/Schema/SchemaException.h>

FdoXmlSchemaMapping* FdoXmlSchemaMapping::Create(
    FdoString* name
)
{
    return new FdoXmlSchemaMapping( name );
}


FdoXmlSchemaMapping::FdoXmlSchemaMapping(
    FdoString* name
)
{
    SetName(name);
}

FdoXmlSchemaMapping::~FdoXmlSchemaMapping()
{
}

FdoString* FdoXmlSchemaMapping::GetProvider()
{
    return FdoXml::mGmlProviderName;
}

void FdoXmlSchemaMapping::SetTargetNamespace( FdoString* url )
{
    mTargetNamespace = url;
}

FdoString* FdoXmlSchemaMapping::GetTargetNamespace()
{
    return mTargetNamespace;
}

FdoXmlElementMappingCollection* FdoXmlSchemaMapping::GetElementMappings()
{
    if ( !mElementMappings )
        mElementMappings = FdoXmlElementMappingCollection::Create(this);

    return FDO_SAFE_ADDREF( (FdoXmlElementMappingCollection*) mElementMappings );
}

FdoXmlClassMappingCollection* FdoXmlSchemaMapping::GetClassMappings()
{
    if ( !mClassMappings )
        mClassMappings = FdoXmlClassMappingCollection::Create(this);

    return FDO_SAFE_ADDREF( (FdoXmlClassMappingCollection*) mClassMappings );
}

void FdoXmlSchemaMapping::Dispose()
{
    delete this;
}

void FdoXmlSchemaMapping::InitFromXml(FdoXmlSaxContext* pContext, FdoXmlAttributeCollection* attrs)
{
    // Cast to the proper XML context
    FdoXmlContext* fdoContext = dynamic_cast<FdoXmlContext*>(pContext);

    // Initialize the parent attributes
    FdoPhysicalSchemaMapping::InitFromXml(pContext, attrs);

    // Check the minimum verion to determine if the current version is
    // greater than the current version. If so, thsi would be an error
    FdoXmlAttributeP att = attrs->FindItem(L"minimumVersion");
    if (att) 
    {
        // Get the minimum and Current versions and  
        FdoStringP minimumFDOVersion = att->GetValue();
        FdoStringP currentFDOVersion = FdoFeatureAccessManager::GetFeatureDataObjectsVersion();

        // Parse them into vectors of numeric values
        FdoVectorP vminFDOVersion = FdoVector::Create(minimumFDOVersion, L".");
        FdoVectorP vcurFDOVersion = FdoVector::Create(currentFDOVersion, L".");

        // Check to see if the minimum version values are less than 
        // or equal to the current version values
        if (vminFDOVersion > vcurFDOVersion)
        {
             throw FdoSchemaException::Create(
                    FdoException::NLSGetMessage(
                        FDO_NLSID(SCHEMA_144_INVALIDMIMIMUMFDOVERSION),
                        (FdoString*)minimumFDOVersion,
                        (FdoString*)currentFDOVersion));
        }
    }

    //TODO deserialize targetNamespace.
}


void FdoXmlSchemaMapping::_writeXml(
    FdoXmlWriter* xmlWriter, 
    const FdoXmlFlags* flags
)
{
    FdoInt32 idx;

    xmlWriter->WriteStartElement( L"SchemaMapping" );
    xmlWriter->WriteAttribute( L"xmlns", L"http://fdo.osgeo.org/schemas/gml/mappings" );


    FdoPhysicalSchemaMapping::_writeXml( xmlWriter, flags );

    if ( mTargetNamespace != L"" ) 
        xmlWriter->WriteAttribute( 
            L"targetNamespace", 
            mTargetNamespace 
       );

    FdoXmlElementMappingsP elemMappings = GetElementMappings();

    for ( idx = 0; idx < elemMappings->GetCount(); idx++ ) {
        FdoXmlElementMappingP( elemMappings->GetItem(idx) )->_writeXml( xmlWriter, flags );
    }

    FdoXmlClassMappingsP classMappings = GetClassMappings();

    for ( idx = 0; idx < classMappings->GetCount(); idx++ ) {
        FdoXmlClassMappingP( classMappings->GetItem(idx) )->_writeXml( xmlWriter, flags );
    }

    xmlWriter->WriteEndElement();
}

FDO_API FdoString* FdoXmlSchemaMapping::GetMinimumProviderVersion()
{
    return m_minimumFDOVersion;
}
