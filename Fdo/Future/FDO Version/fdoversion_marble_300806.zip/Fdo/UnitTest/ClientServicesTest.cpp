/***************************************************************************
 * 
* Copyright (C) 2004-2006  Autodesk, Inc.
* 
* This library is free software; you can redistribute it and/or
* modify it under the terms of version 2.1 of the GNU Lesser
* General Public License as published by the Free Software Foundation.
* 
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
* 
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
* 
 ***************************************************************************/

#include "Pch.h"
#include <iostream>
#include <fstream>
#ifdef _WIN32
#include <winnls.h>
#endif
#include "ClientServicesTest.h"
#include "Fdo/ClientServices/ClientServices.h"
#include "Fdo/ClientServices/FeatureAccessManager.h"
#include "Fdo/ClientServices/ConnectionManager.h"
#include "Fdo/ClientServices/ProviderRegistry.h"
#include "Fdo/ClientServices/ClientServiceException.h"
#include "Fdo/ClientServices/Provider.h"

CPPUNIT_TEST_SUITE_REGISTRATION( ClientServicesTest );
CPPUNIT_TEST_SUITE_NAMED_REGISTRATION( ClientServicesTest, "ClientServicesTest");

ClientServicesTest::ClientServicesTest(void)
{
}

ClientServicesTest::~ClientServicesTest(void)
{
}

void ClientServicesTest::setUp ()
{
    dt1 = new FdoCSTestData(std::wstring(L"Autodesk.Oracle.3.2"), 
                            std::wstring(L"Oracle"), 
                            std::wstring(L"Oracle Spatial FDO Provider"), 
                            std::wstring(L"3.2.0.0"), 
                            std::wstring(L"3.2.0.0"), 
#ifdef _WIN32
                            std::wstring(L"FdoRdbms.dll"), // relies on the unit test being in the same 
#else
                            std::wstring(L"libFdoRdbms.so"), // relies on the unit test being in the same 
#endif
                                                           // directory as FdoRdbms.dll -- //danube\Bin\Win32\Debug
                            false);

    dt2 = new FdoCSTestData(std::wstring(L"TestData2"), 
                            std::wstring(L"TestData2"), 
                            std::wstring(L"TestDescription2"), 
                            std::wstring(L"3.1.2.0"), 
                            std::wstring(L"3.1.0.0"), 
                            std::wstring(L"c:\\Test2\\test2.dll"),
                            true);

    dt3 = new FdoCSTestData(std::wstring(L"TestData3"), 
                            std::wstring(L"TestData3"), 
                            std::wstring(L"TestDescription3"), 
                            std::wstring(L"3.0.3.0"), 
                            std::wstring(L"3.0.0.0"), 
                            std::wstring(L"c:\\Test3\\test.dll"),
                            true);

}

void ClientServicesTest::tearDown ()
{
    delete dt1;
    delete dt2;
    delete dt3;
}

void ClientServicesTest::TestServices ()
{
    try 
    {
        FdoStringP fdoVersion = FdoFeatureAccessManager::GetFeatureDataObjectsVersion();
        if (fdoVersion != L"3.2.0.0") {
            throw "Invalid FDo Version returned from FdoFeatureAccessManager::GetFeatureDataObjectsVersion";
        }

        FdoPtr<IProviderRegistry> registry = FdoFeatureAccessManager::GetProviderRegistry();
        if (registry == NULL) {
            throw "NULL Registry Pointer";
        }

        FdoPtr<FdoProviderCollection> collection = registry->GetProviders();
        int initialCount = collection->GetCount();

        registry->RegisterProvider(dt1->m_name.c_str(), 
                                   dt1->m_displayName.c_str(), 
                                   dt1->m_description.c_str(), 
                                   dt1->m_version.c_str(), 
                                   dt1->m_fdoVersion.c_str(), 
                                   dt1->m_libraryPath.c_str(),
                                   dt1->m_isManaged);

        registry->RegisterProvider(dt2->m_name.c_str(), 
                                   dt2->m_displayName.c_str(), 
                                   dt2->m_description.c_str(), 
                                   dt2->m_version.c_str(), 
                                   dt2->m_fdoVersion.c_str(), 
                                   dt2->m_libraryPath.c_str(),
                                   dt2->m_isManaged);

        registry->RegisterProvider(dt3->m_name.c_str(), 
                                   dt3->m_displayName.c_str(), 
                                   dt3->m_description.c_str(), 
                                   dt3->m_version.c_str(), 
                                   dt3->m_fdoVersion.c_str(), 
                                   dt3->m_libraryPath.c_str(),
                                   dt3->m_isManaged);

        collection = registry->GetProviders();

        FdoPtr<FdoProvider> provider = collection->GetItem(collection->IndexOf(dt1->m_name.c_str()));
        if (provider == NULL) {
            throw "NULL Provider pointer";
        }

        if (dt1->m_name.compare(provider->GetName()) != 0) {
            throw "Wrong provider name returned from collection";
        }

        if (dt1->m_displayName.compare(provider->GetDisplayName()) != 0) {
            throw "Wrong provider display name returned from collection";
        }

        if (dt1->m_description.compare(provider->GetDescription()) != 0) {
            throw "Wrong provider description returned from collection";
        }

        if (dt1->m_version.compare(provider->GetVersion()) != 0) {
            throw "Wrong provider version returned from collection";
        }

        if (dt1->m_fdoVersion.compare(provider->GetFeatureDataObjectsVersion()) != 0) {
            throw "Wrong provider fdo version returned from collection";
        }

        if (dt1->m_libraryPath.compare(provider->GetLibraryPath()) != 0) {
            throw "Wrong provider library path returned from collection";
        }

        if (dt1->m_isManaged != provider->GetIsManaged()) {
            throw "Wrong provider managed state returned from collection";
        }

        FdoPtr<IConnectionManager> connectionMgr = FdoFeatureAccessManager::GetConnectionManager();
        if (connectionMgr == NULL) {
            throw "NULL ConnectionManager pointer";
        }

        // Note: the actual connection creation is 
        // tested by the SDK installation/build/execute.

        registry->UnregisterProvider(dt2->m_name.c_str());
        registry->UnregisterProvider(dt3->m_name.c_str());
        registry->UnregisterProvider(dt1->m_name.c_str());
    }
    catch (FdoClientServiceException *cse)
    {
        std::wcerr << L"\n" << std::endl;
        std::wcerr << cse->GetExceptionMessage() << std::endl;
        char msg[1024];
#ifdef _WIN32
        WideCharToMultiByte (
            CP_UTF8,            // code page
            0,                  // performance and mapping flags
            cse->GetExceptionMessage(),              // wide-character string
            (int)wcslen (cse->GetExceptionMessage()) + 1,// number of chars in string
            msg,                // buffer for new string
            sizeof(msg),        // size of buffer
            NULL,               // default for unmappable chars
            NULL                // set when default char used
        );
#else
	wcstombs(msg, cse->GetExceptionMessage(), sizeof(msg));		
#endif
        delete cse;
        CPPUNIT_FAIL (msg);
    }
    catch (char* message)
    {
        std::cerr << "\n" << std::endl;
        std::cerr << message << std::endl;
        CPPUNIT_FAIL (message);
    }
    catch (...)
    {
        std::cerr << "\nUnhandled Exception" << std::endl;
        CPPUNIT_FAIL ("Unhandled Exception");
    }

    return;
}

void ClientServicesTest::TestProviderNameTokens ()
{
    try 
    {
        FdoProviderNameTokensP tokens1;
        if (tokens1.p != NULL)
            throw "Failure: tokens1->GetLocalName() != NULL";

        tokens1 = FdoProviderNameTokens::Create(L"Autodesk.Oracle.3.2");
        if (tokens1->GetLocalName() != L"Oracle")
           throw "Failure: tokens1->GetLocalName() != Oracle";

        FdoStringsP nameTokens = tokens1->GetNameTokens();
        if (nameTokens->GetCount() != 4)
           throw "Failure: nameTokens->GetCount() != 4";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"Oracle") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != Oracle";

        if (FdoStringP(L"3") != nameTokens->GetString(2))
           throw "Failure: nameTokens->GetCount(2) != 3";

        if (FdoStringP(L"2") != nameTokens->GetString(3))
           throw "Failure: nameTokens->GetCount(3) != 2";

        nameTokens = tokens1->GetNameTokens(false);
        if (nameTokens->GetCount() != 2)
           throw "Failure: nameTokens->GetCount() != 2";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"Oracle") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != Oracle";

        FdoVectorP verTokens = tokens1->GetVersionTokens();
        if (verTokens->GetCount() != 2)
           throw "Failure: verTokens->GetCount() != 2";

        if (verTokens->GetValue(0) != 3)
           throw "Failure: nameTokens->GetItem(0) != 3";

        if (verTokens->GetValue(1) != 2)
           throw "Failure: nameTokens->GetCount(1) != 2";

        FdoStringP strToken1 = tokens1->ToString(true);
        if (FdoStringP(L"Autodesk.Oracle.3.2") != strToken1)
           throw "Failure: tokens1->ToString(true) != Autodesk.Oracle.3.2";

        FdoStringP strToken2 = tokens1->ToString(false);
        if (FdoStringP(L"Autodesk.Oracle") != strToken2)
           throw "Failure: tokens1->ToString(false) != Autodesk.Oracle";

        FdoProviderNameTokensP tokens2 = FdoProviderNameTokens::Create(L"Autodesk.Oracle.3.2");
        if (tokens1 != tokens2)
           throw "Failure: tokens1 != tokens2";

        tokens1 = FdoProviderNameTokensP();
        if (tokens1.p != NULL)
            throw "Failure: tokens1->GetLocalName() != NULL";

        ////////////////////

        tokens1 = FdoProviderNameTokens::Create(L"Autodesk.SQLServer.3");
        if (tokens1->GetLocalName() != L"SQLServer")
           throw "Failure: tokens1->GetLocalName() != SQLServer";

        nameTokens = tokens1->GetNameTokens();
        if (nameTokens->GetCount() != 3)
           throw "Failure: nameTokens->GetCount() != 3";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"SQLServer") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != SQLServer";

        if (FdoStringP(L"3") != nameTokens->GetString(2))
           throw "Failure: nameTokens->GetCount(2) != 3";

        verTokens = tokens1->GetVersionTokens();
        if (verTokens->GetCount() != 1)
           throw "Failure: verTokens->GetCount() != 1";

        if (verTokens->GetValue(0) != 3)
           throw "Failure: nameTokens->GetItem(0) != 3";

        strToken1 = tokens1->ToString(true);
        if (FdoStringP(L"Autodesk.SQLServer.3") != strToken1)
           throw "Failure: tokens1->ToString(true) != Autodesk.SQLServer.3";

        strToken2 = tokens1->ToString(false);
        if (FdoStringP(L"Autodesk.SQLServer") != strToken2)
           throw "Failure: tokens1->ToString(false) != Autodesk.SQLServer";

        tokens2 = FdoProviderNameTokens::Create(L"Autodesk.SQLServer.3");
        if (tokens1 != tokens2)
           throw "Failure: tokens1 != tokens2";

        ////////////////////

        tokens1 = FdoProviderNameTokens::Create(L"Autodesk.MySQL");
        if (tokens1->GetLocalName() != L"MySQL")
           throw "Failure: tokens1->GetLocalName() != MySQL";

        nameTokens = tokens1->GetNameTokens();
        if (nameTokens->GetCount() != 2)
           throw "Failure: nameTokens->GetCount() != 2";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"MySQL") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != MySQL";

        nameTokens = tokens1->GetNameTokens(false);
        if (nameTokens->GetCount() != 2)
           throw "Failure: nameTokens->GetCount() != 2";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"MySQL") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != MySQL";

        verTokens = tokens1->GetVersionTokens();
        if (verTokens->GetCount() != 0)
           throw "Failure: verTokens->GetCount() != 0";

        strToken1 = tokens1->ToString(true);
        if (FdoStringP(L"Autodesk.MySQL") != strToken1)
           throw "Failure: tokens1->ToString(true) != Autodesk.MySQL";

        strToken2 = tokens1->ToString(false);
        if (FdoStringP(L"Autodesk.MySQL") != strToken2)
           throw "Failure: tokens1->ToString(false) != Autodesk.MySQL";

        tokens2 = FdoProviderNameTokens::Create(L"Autodesk.MySQL");
        if (tokens1 != tokens2)
           throw "Failure: tokens1 != tokens2";

        ////////////////////

        tokens1 = FdoProviderNameTokens::Create(L"Autodesk.ODBC.3.2.1");
        if (tokens1->GetLocalName() != L"ODBC")
           throw "Failure: tokens1->GetLocalName() != ODBC";

        nameTokens = tokens1->GetNameTokens();
        if (nameTokens->GetCount() != 5)
           throw "Failure: nameTokens->GetCount() != 5";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"ODBC") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != ODBC";

        if (FdoStringP(L"3") != nameTokens->GetString(2))
           throw "Failure: nameTokens->GetCount(2) != 3";

        if (FdoStringP(L"2") != nameTokens->GetString(3))
           throw "Failure: nameTokens->GetCount(3) != 2";

        if (FdoStringP(L"1") != nameTokens->GetString(4))
           throw "Failure: nameTokens->GetCount(4) != 1";

        nameTokens = tokens1->GetNameTokens(false);
        if (nameTokens->GetCount() != 2)
           throw "Failure: nameTokens->GetCount() != 2";

        if (FdoStringP(L"Autodesk") != nameTokens->GetString(0))
           throw "Failure: nameTokens->GetItem(0) != Autodesk";

        if (FdoStringP(L"ODBC") != nameTokens->GetString(1))
           throw "Failure: nameTokens->GetCount(1) != ODBC";

        verTokens = tokens1->GetVersionTokens();
        if (verTokens->GetCount() != 3)
           throw "Failure: verTokens->GetCount() != 2";

        if (verTokens->GetValue(0) != 3)
           throw "Failure: nameTokens->GetItem(0) != 3";

        if (verTokens->GetValue(1) != 2)
           throw "Failure: nameTokens->GetCount(1) != 2";

        if (verTokens->GetValue(2) != 1)
           throw "Failure: nameTokens->GetCount(2) != 1";

        strToken1 = tokens1->ToString(true);
        if (FdoStringP(L"Autodesk.ODBC.3.2.1") != strToken1)
           throw "Failure: tokens1->ToString(true) != Autodesk.ODBC.3.2.1";

        strToken2 = tokens1->ToString(false);
        if (FdoStringP(L"Autodesk.ODBC") != strToken2)
           throw "Failure: tokens1->ToString(false) != Autodesk.ODBC";

        tokens2 = FdoProviderNameTokens::Create(L"Autodesk.ODBC.3.2.1");
        if (tokens1 != tokens2)
           throw "Failure: tokens1 != tokens2";
    }
    catch (FdoClientServiceException *cse)
    {
        std::wcerr << L"\n" << std::endl;
        std::wcerr << cse->GetExceptionMessage() << std::endl;
        CPPUNIT_FAIL ((const char*)FdoStringP(cse->GetExceptionMessage()));
    }
    catch (char* message)
    {
        std::cerr << "\n" << std::endl;
        std::cerr << message << std::endl;
        CPPUNIT_FAIL (message);
    }
    catch (...)
    {
        std::cerr << "\nUnhandled Exception" << std::endl;
        CPPUNIT_FAIL ("Unhandled Exception");
    }

    return;
}

void ClientServicesTest::TestCompatibleProviders ()
{
    try 
    {
        FdoPtr<IProviderRegistry> registry = FdoFeatureAccessManager::GetProviderRegistry();
        if (registry == NULL) {
            throw "NULL Registry Pointer";
        }

        FdoPtr<FdoProviderCollection> collection = registry->GetProviders();
        int initialCount = collection->GetCount();

        registry->RegisterProvider(dt1->m_name.c_str(), 
                                   dt1->m_displayName.c_str(), 
                                   dt1->m_description.c_str(), 
                                   dt1->m_version.c_str(), 
                                   dt1->m_fdoVersion.c_str(), 
                                   dt1->m_libraryPath.c_str(),
                                   dt1->m_isManaged);

        registry->RegisterProvider(dt2->m_name.c_str(), 
                                   dt2->m_displayName.c_str(), 
                                   dt2->m_description.c_str(), 
                                   dt2->m_version.c_str(), 
                                   dt2->m_fdoVersion.c_str(), 
                                   dt2->m_libraryPath.c_str(),
                                   dt2->m_isManaged);

        registry->RegisterProvider(dt3->m_name.c_str(), 
                                   dt3->m_displayName.c_str(), 
                                   dt3->m_description.c_str(), 
                                   dt3->m_version.c_str(), 
                                   dt3->m_fdoVersion.c_str(), 
                                   dt3->m_libraryPath.c_str(),
                                   dt3->m_isManaged);

        collection = registry->GetProviders(false);
        if (collection->GetCount() != 3)
           throw "Failure: collection->GetCount() != 3";

        collection = registry->GetProviders(true);
        if (collection->GetCount() != 1)
           throw "Failure: collection->GetCount() != 1";

        FdoPtr<FdoProvider> provider = collection->GetItem(0);
        if (provider == NULL) {
            throw "NULL Provider pointer";
        }

        if (dt1->m_name.compare(provider->GetName()) != 0) {
            throw "Wrong provider name returned from collection";
        }

        registry->UnregisterProvider(dt2->m_name.c_str());
        registry->UnregisterProvider(dt3->m_name.c_str());
        registry->UnregisterProvider(dt1->m_name.c_str());
    }
    catch (FdoClientServiceException *cse)
    {
        std::wcerr << L"\n" << std::endl;
        std::wcerr << cse->GetExceptionMessage() << std::endl;
        CPPUNIT_FAIL ((const char*)FdoStringP(cse->GetExceptionMessage()));
    }
    catch (char* message)
    {
        std::cerr << "\n" << std::endl;
        std::cerr << message << std::endl;
        CPPUNIT_FAIL (message);
    }
    catch (...)
    {
        std::cerr << "\nUnhandled Exception" << std::endl;
        CPPUNIT_FAIL ("Unhandled Exception");
    }

    return;
}
