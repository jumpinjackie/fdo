#ifndef CPPUNITTEST_EXTENSIONSSUITE_H
#define CPPUNITTEST_EXTENSIONSSUITE_H

#include <string>

namespace CppUnitTest
{

  inline std::string extensionSuiteName()
  {
    return "Extensions";
  }

}

#endif // CPPUNITTEST_EXTENSIONSSUITE_H