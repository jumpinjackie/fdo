#ifndef CPPUNITTEST_OUTPUTSUITE_H
#define CPPUNITTEST_OUTPUTSUITE_H

#include <string>

namespace CppUnitTest
{

  inline std::string outputSuiteName()
  {
    return "Output";
  }

}

#endif // CPPUNITTEST_OUTPUTSUITE_H