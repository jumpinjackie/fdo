#ifndef CPPUNITTEST_UNITTESTTOOLSUITE_H
#define CPPUNITTEST_UNITTESTTOOLSUITE_H

#include <string>

namespace CppUnitTest
{

  inline std::string unitTestToolSuiteName()
  {
    return "UnitTestTool";
  }

}

#endif // CPPUNITTEST_UNITTESTTOOLSUITE_H