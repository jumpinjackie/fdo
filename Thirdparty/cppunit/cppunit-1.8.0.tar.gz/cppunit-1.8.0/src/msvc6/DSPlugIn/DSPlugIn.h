// DSPlugIn.h : main header file for the DSPLUGIN DLL
//

#if !defined(AFX_DSPLUGIN_H__4DD05CAB_F04B_43DE_8B5D_17B299239CD9__INCLUDED_)
#define AFX_DSPLUGIN_H__4DD05CAB_F04B_43DE_8B5D_17B299239CD9__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include <ObjModel\addguid.h>
#include <ObjModel\appguid.h>
#include <ObjModel\bldguid.h>
#include <ObjModel\textguid.h>
#include <ObjModel\dbgguid.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSPLUGIN_H__4DD05CAB_F04B_43DE_8B5D_17B299239CD9__INCLUDED)
