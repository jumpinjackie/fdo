//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestRunner.rc
//
#define IDS_ERROR_SELECT_TEST           1
#define IDS_ERRORLIST_TYPE              2
#define IDS_ERRORLIST_NAME              3
#define IDS_ERRORLIST_FAILED_CONDITION  4
#define IDS_ERRORLIST_LINE_NUMBER       5
#define IDS_ERRORLIST_FILE_NAME         6
#define IDD_DIALOG_TESTRUNNER           129
#define IDD_DIALOG_TEST_HIERARCHY       130
#define IDB_TEST_TYPE                   131
#define IDR_ACCELERATOR_TEST_RUNNER     131
#define IDB_ERROR_TYPE                  134
#define IDC_LIST                        1000
#define ID_RUN                          1001
#define ID_STOP                         1002
#define IDC_PROGRESS                    1003
#define IDC_INDICATOR                   1004
#define IDC_COMBO_TEST                  1005
#define IDC_STATIC_RUNS                 1007
#define IDC_STATIC_ERRORS               1008
#define IDC_STATIC_FAILURES             1009
#define IDC_EDIT_TIME                   1010
#define IDC_BUTTON1                     1011
#define IDC_BROWSE_TEST                 1011
#define IDC_TREE_TEST                   1012
#define IDC_CHECK_AUTORUN               1013
#define ID_QUIT_APPLICATION             32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
