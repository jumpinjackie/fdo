#ifndef CPPUNITTEST_HELPERSUITE_H
#define CPPUNITTEST_HELPERSUITE_H

#include <string>

namespace CppUnitTest
{

  inline std::string helperSuiteName()
  {
    return "Helpers";
  }

}

#endif // CPPUNITTEST_HELPERSUITE_H